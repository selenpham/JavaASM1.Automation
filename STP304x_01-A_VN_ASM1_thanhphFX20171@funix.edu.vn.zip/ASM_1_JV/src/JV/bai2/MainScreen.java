package JV.bai2;
import java.util.Scanner;
public class MainScreen {
// Tạo công thức tính tổng của các số lẻ từ 1 đến n
    public int tongsole(int n) {
        int sum = 0;
        for (int i = 0; i <= n; i++) {
            if (i % 2 != 0) {
                sum += i;}
        }return sum;
    }
// Tạo công thức tính tổng của các số chẵn từ 1 đến n
    public int tongsochan(int n) {
        int sum = 0;
        for (int i = 0; i <= n; i++) {
            if (i % 2 == 0) {
                sum += i;}
        }return sum;
    }
// Tạo công thức đếm các số chia hết 3 nhưng không chia hết 2 tronh khoảng từ 1-n
    public int chiahet(int n) {
        int count = 0;
        for (int i = 0; i <= n; i++) {
            if (i % 3 == 0 && i % 2 != 0) {
                count++;}
        }return count;
    }
    public static void main(String[] args) {
        MainScreen o = new MainScreen();
        Scanner scanner = new Scanner(System.in);
        int n;
// Kiểm tra giá trị của số được nhập, nếu là khoảng trắng hoặc chữ số thì hiện cảnh báo, yêu cầu nhập lại
        do {
            System.out.print("Nhap so n: ");
            if (scanner.hasNextInt()) {//số nhập vào là số thì kiểm tra tiếp nếu số đó >0
                n = scanner.nextInt();
                if (n <= 0) {
                    System.out.println("\tVui long nhap n > 0!");}
            } else {
                String input = scanner.next(); //Số nhập vào là chữ cái/chuỗi/khoảng trắng thì báo lỗi
                System.out.println("\tGia tri n khong hop le. Vui long nhap lai n > 0!");
                n = 0; }
        } while (n <= 0);
// In ra các yêu cầu của đề bài        
        int soLe = o.tongsole(n);
        System.out.println("\tTong cac so le tu 1 den " + n + " la: " + soLe);

        int soChan = o.tongsochan(n);
        System.out.println("\tTong cac so chan tu 1 den " + n + " la: " + soChan);

        int chiaHet = o.chiahet(n);
        System.out.println("\tTu 1 den " +n + " co " + chiaHet + " so chia het 3 nhung khong chia het 2 ");
    }
}