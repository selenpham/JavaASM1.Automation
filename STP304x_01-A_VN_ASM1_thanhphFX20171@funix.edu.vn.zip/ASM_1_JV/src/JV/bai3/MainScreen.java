package JV.bai3;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

public class MainScreen {
	
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Student> studentinf = new ArrayList<>();
// Tạo vòng lặp liên tục cho tới khi nhấn N thì thoát không nhập nữa
        boolean isContinue = true;       
        while (isContinue) {
            Student std = new Student();
// Tạo đk ràng buộc tên. Tên để trống sẽ bị báo lỗi và yêu cầu nhập          
            boolean validName = false; 
            do {
            	try {
            		System.out.print("Enter full name: ");
            		String name = scanner.nextLine().toUpperCase();
            		if(name.equals("")){
                        throw new IllegalArgumentException();
                    }
                    std.setFullName(name);
                    validName = true;
                } catch (IllegalArgumentException e) {
                    System.out.println("Fullname cannot be blank, please enter Fullname");
                }
            } while (!validName);
// Tạo đk ràng buộc địa chỉ. Địa chỉ để trống sẽ bị báo lỗi và yêu cầu nhập                
            boolean validAddress = false; 
            do {
            	try {
            		System.out.print("Enter address: ");
            		String address = scanner.nextLine().toUpperCase();
            		if(address.equals("")){
                        throw new IllegalArgumentException();
                    }
                    std.setAddress(address);
                    validAddress = true;
                } catch (IllegalArgumentException e) {
                    System.out.println("Address cannot be blank, please enter Address");
                }
            } while (!validAddress);
// Nhập ngày tháng năm sinh, nếu giá trị nhập ko đúng định dạng thì báo lỗi
            boolean validDOB = false;
            do {
                try {
                    System.out.print("Enter date of birth (dd/mm/yyyy): ");
                    String dobInput = scanner.nextLine();
                    String[] dobArray = dobInput.split("/");
// Kiểm tra nếu nhập đúng 3 phần ngày sinh, tháng sinh, năm sinh, ba phần cách nhau bởi kí hiệu "/"
                    if (dobArray.length != 3) {
                        throw new NumberFormatException();
                    }
                    int date = Integer.parseInt(dobArray[0]);
                    int month = Integer.parseInt(dobArray[1]);
                    int year = Integer.parseInt(dobArray[2]);
// Kiểm tra nếu giá trị ngày, tháng , năm hợp lệ
                    if (date >= 1 && date <= 31 && month >= 1 && month <= 12 && dobArray[2].length() == 4) {
                        std.setDob(dobInput);
                        validDOB = true;
                    } else {
                        throw new IllegalArgumentException();
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid date format. Please enter in the format dd/mm/yyyy.");
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid value. Please enter a valid value in the format dd/mm/yyyy.");
                } catch (Exception e) {
                    System.out.println("Invalid date format. Please enter a valid date in the format dd/mm/yyyy.");
                }
            } while (!validDOB);
// Nhập giới tính, chỉ có 2 lựa chọn là male,female, nếu nhập sai sẽ bị báo lỗi
            boolean validGender = false;
            do {
                try {
                    System.out.print("Enter gender (MALE/FEMALE): ");
                    String gender = scanner.nextLine().toUpperCase();
                    if (!gender.equals("MALE") && !gender.equals("FEMALE")) {
                        throw new IllegalArgumentException();
                    }
                    std.setGender(gender);
                    validGender = true;
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid gender format, please enter either 'Male' or 'Female'");
                }
            } while (!validGender);
// Nhập điểm với ràng buộc điểm từ 0-10, ngoài giới hạn này báo lỗi
            boolean validGrade = false;
            do {
                try {
                    System.out.print("Enter final grade: ");
                    std.setFinalGrade(Float.parseFloat(scanner.nextLine()));
                    if (std.getFinalGrade() < 0 || std.getFinalGrade() > 10) {
                        throw new IllegalArgumentException();
                    }
                    validGrade = true;
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid final grade format, please enter a number between 0 and 10");
                }
            } while (!validGrade);
// Sau mỗi lần nhập xong hỏi có tiếp tục nhập hay không, nếu nhập N thì thoát vòng lặp
            studentinf.add(std);
            System.out.println("Do you want to continue? (Y/N): ");

            String stdinput = scanner.nextLine();
            if ("N".equalsIgnoreCase(stdinput)) {
                isContinue = false;
            }
        }
//b.In ra tất cả thông tin của học sinh trong danh sách
        System.out.println("\nDanh sach cac hoc sinh da nhap nhu sau:");
		for (int i =0; i<studentinf.size();i++) {
			Student std = studentinf.get(i);
			System.out.println("Student " + (i + 1) + ":");
			System.out.println("\tFullName: " + std.getFullName().toUpperCase());
			System.out.println("\tAddress: " + std.getAddress().toUpperCase());
			System.out.println("\tDate of birth: " + std.getDob().toUpperCase());
			System.out.println("\tGender: " + std.getGender().toUpperCase());
			System.out.println("\tFinal Grade: " + std.getFinalGrade());
		}
//c. In ra học lực của các học sinh
		System.out.println("\nHoc luc cac hoc sinh nhu sau: ");
		for (int i = 0; i<studentinf.size();i++) {
			float finalGrade = studentinf.get(i).getFinalGrade();
			if(finalGrade<4) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc kem");
			}
			else if(finalGrade<5) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc yeu");
			}
			else if(finalGrade<5.5) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc trung binh yeu");
			}
			else if(finalGrade<6.5) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc trung binh ");
			}
			else if(finalGrade<7) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc trung binh kha");
			}
			else if(finalGrade<8) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc kha");
			}
			else if(finalGrade<8.5) {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc kha gioi");
			}
			else {
				System.out.println("\tHoc sinh " + studentinf.get(i).getFullName() + ": hoc luc gioi");
			}
		}
//d. Tính điểm trung bình của danh sách học sinh
		float totalGrade = 0;
		for(int i=0; i<studentinf.size();i++) {
			totalGrade +=studentinf.get(i).getFinalGrade(); 
		}
		float avgGrade = totalGrade/studentinf.size();
		System.out.println("\nDiem trung binh cua danh sach hoc sinh la: " + avgGrade);
	}
}
