package JV.bai3;

public class Student {
	
//Tạo đối tượng Student bao gồm các thông tin cơ bản: fullName, address, dob, gender, finalGrade
    private String fullName;
    private String address;
    private String dob;
    private String gender;
    private float finalGrade;
//Tạo phương thức get,set cho FullName
    public String getFullName() {
        return fullName;
    }
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
//Tạo phương thức get,set cho address
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
//Tạo phương thức get,set cho dob
    public String getDob() {
        return dob;
    }
    public void setDob(String dob) {
        this.dob = dob;
    }
//Tạo phương thức get,set cho gender
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
//Tạo phương thức get,set cho finalGrade
    public float getFinalGrade() {
        return finalGrade;
    }
    public void setFinalGrade(float finalGrade) {
        this.finalGrade = finalGrade;
    }
}

