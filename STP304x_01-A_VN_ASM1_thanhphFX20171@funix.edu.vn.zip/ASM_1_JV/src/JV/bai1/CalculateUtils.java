package JV.bai1;

public class CalculateUtils{
//Tạo đối tượng CalculateUtils có thuộc tính x,y
			public double x;
		    public double y;
// Tạo công thức tính cộng
		    public double tinhCong(double x, double y) {
		        double tinhCong = x + y;
		        return tinhCong;
		    }
// Tạo công thức tính trừ
		    public double tinhTru(double x, double y) {
		        double tinhTru = x - y;
		        return tinhTru;
		    }
// Tạo công thức tính nhân
		    public double tinhNhan(double x, double y) {
		        double tinhNhan = x * y;
		        return tinhNhan;
		    }
// Tạo công thức tính chia
		    public double tinhChia(double x, double y) {
		        double tinhChia = x / this.y;
		        return tinhChia;
		    }
}


