package JV.bai1;

import java.util.Scanner;

import JV.bai1.CalculateUtils;

public class MyMainClass {
	public static void main(String[]args) {
		CalculateUtils o = new CalculateUtils();
		Scanner scanner = new Scanner(System.in);
//Nhập số x và tạo điều kiện ràng buộc x không trống, x là số
		double x1 = 0;
		while(true) {
		    System.out.print("Nhap so x: ");
		    try 
		    {
		        String input = scanner.nextLine();
		        x1 = Double.parseDouble(input);
		        break; // Thoát vòng lặp nếu x là số hợp lệ
		    } catch (NumberFormatException e) 
		    {
		        System.out.println("Gia tri x khong hop le! Vui long nhap lai 1 so khac.");
		    }
		}
		o.x = x1;
//Nhập số y và tạo điều kiện ràng buộc y không trống, y là số
		double y1 = 0;
		while(true) {
			System.out.print("Nhap so y: ");
		    try 
		    {	
		       String input = scanner.nextLine();
		       y1 = Double.parseDouble(input);
		       break; // Thoát vòng lặp nếu x là số hợp lệ
		    } catch (NumberFormatException e) 
		    {
		       System.out.println("Gia tri y khong hop le! Vui long nhap lai 1 so khac.");
		    }
		}
		o.y = y1;
// Tạo vòng lặp nhập action cho tới khi chọn exit thì thoát action
     boolean exit = false;
     while (!exit) 
     {
        System.out.println("Nhap ACTION: (CONG/TRU/NHAN/CHIA/EXIT)");
        String action = scanner.next().toLowerCase();
        switch (action) {
            case "cong":
                System.out.println(o.tinhCong(x1, y1));
                break;
            case "tru":
                System.out.println(o.tinhTru(x1, y1));
                break;
            case "nhan":
                System.out.println(o.tinhNhan(x1, y1));
                break;
            case "chia":
//Nếu làm tròn thì sử dụng: System.out.println(Math.round(o.tinhChia()*10)/10);
                System.out.println(o.tinhChia(x1, y1));
                break;
            case "exit":
                exit = true;
                break;
            default: // Nếu nhập giá trị khác ngoài 5 action trên thì không hợp lệ
                System.out.println("Gia tri action khong hop le");
                break;
        	}
     	}
   	}
}
	
	

